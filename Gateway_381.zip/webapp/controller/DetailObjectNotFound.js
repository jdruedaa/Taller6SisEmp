sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.sap.ua.Gateway_381.controller.DetailObjectNotFound", {});
});
